    <!-- Admin Header End -->

    <!-- For jquery -->
    <script src="assets/js/jquery-3.5.1.min.js"></script>
    <!-- For boostrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- For popper cdn 2.9.x -->
    <script src="assets/js/popper.min.js"></script>

    <!-- For fontawesome -->
    <script src="assets/js/font-awesome.min.js"></script>

    <!-- For swipper slider -->
    <script src="assets/js/swiper-bundle.min.js"></script>

    <!-- For mixiup -- filter -->
    <script src="assets/js/jquery.mixitup.min.js"></script>

    <!-- For fancybox -->
    <script src="assets/js/jquery.fancybox.min.js"></script>

    <!-- For parallax -->
    <script src="assets/js/parallax.min.js"></script>

    <!-- For gsap -->
    <script src="assets/js/gsap.min.js"></script>

    <!-- For scroll trigger -->
    <script src="assets/js/ScrollTrigger.min.js"></script>
    <!-- For scroll to plugin -->
    <script src="assets/js/ScrollToPlugin.min.js"></script>
    <!-- For rellax -->
    <!-- <script src="assets/js/rellax.min.js"></script>
      <script src="assets/js/rellax-custom.js"></script> -->
    <!-- For smooth scroll -->
    <script src="assets/js/smooth-scroll.js"></script>
    <!-- For custom js -->
    <script src="assets/js/main.js"></script>
  </body>
</html>