
<div class="sma-right">
            <div class="sma-r-top">
              <div class="sma-rt-left">
                <div class="sma-rt-l-title eh6">Profile</div>
                <div class="sma-rt-l-content eh" style="color: var(--grey-01)">
                  User Profile
                </div>
              </div>
            </div>
            <div class="sma-r-bot">
              <div class="sma-rb-start"></div>
              <form action="" method="post" enctype="multipart/form-data">
                <div class="sma-rb-item">
                  <label for="">First Name</label>
                  <input type="text" name="user_fname"/>
                </div>
                <div class="sma-rb-item">
                  <label for="">Last Name</label>
                  <input type="text" name="user_lname"/>
                </div>
                <div class="sma-rb-item">
                  <label for="">Email</label>
                  <input type="text" name="user_email"/>
                </div>
                <div class="sma-rb-item">
                  <label for="">Phone</label>
                  <input type="text" name="user_phone"/>
                </div>
                <div class="sma-rb-item">
                  <label for="">User Name</label>
                  <input type="text" name="user_name"/>
                </div>
                <div class="sma-rb-item">
                  <label for="">Password</label>
                  <input type="text" name="user_password"/>
                </div>
                <!-- <div class="sma-rb-item">
                  <label for="insert-img">
                    <i class="uil uil-cloud-upload"></i>
                    <div class="sma-rb-i-title">
                      Drag and drop a file to upload
                    </div>
                  </label>
                  <input type="file" id="insert-img" name="user_image"/>
                </div> -->
              <div class="sma-r-end">
                <div class="btn-main">
                  <button class="btn-general" type="submit" name="profile_user">Submit</button>
                  <button class="btn-ghost" type="submit" name="cancel">Cancel</button>
                </div>
              </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>