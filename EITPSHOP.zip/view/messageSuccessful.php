
  <section class="message">
    <div class="container">
      <div class="site-message">
        <svg width="139" height="138" viewBox="0 0 139 138" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path opacity="0.1"
            d="M69.498 126.5C101.254 126.5 126.998 100.756 126.998 68.9998C126.998 37.2434 101.254 11.4998 69.498 11.4998C37.7417 11.4998 11.998 37.2434 11.998 68.9998C11.998 100.756 37.7417 126.5 69.498 126.5Z"
            fill="#1D9E34" />
          <path
            d="M61.3382 89.5846C60.1882 89.5846 59.0957 89.1246 58.2907 88.3196L42.0182 72.0471C40.3507 70.3796 40.3507 67.6196 42.0182 65.9521C43.6857 64.2846 46.4457 64.2846 48.1132 65.9521L61.3382 79.1771L90.8932 49.6221C92.5607 47.9546 95.3207 47.9546 96.9882 49.6221C98.6557 51.2896 98.6557 54.0496 96.9882 55.7171L64.3857 88.3196C63.5807 89.1246 62.4882 89.5846 61.3382 89.5846Z"
            fill="#1D9E34" />
        </svg>
        <div class="sm-title eh3">Your Payment is Succesfull</div>
        <div class="sm-content p1-regular-16" style="color: var(--grey-01)">Your payment will be proceed in 30 mins. If
          any problem please chat to customer service. Detail information will included below.</div>
        <div class="btn-main">
          <a href="?mod=page&act=home">
            <button class="btn-general eh">Back to home</button>
          </a>
          <button class="btn-general eh">Check Detail</button>
        </div>
      </div>
    </div>
  </section>
